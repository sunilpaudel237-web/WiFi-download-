# WiFi Drop

Send files from your phone to any device on the same WiFi.

## Run

    pip install -r requirements.txt
    python app.py

The terminal prints an address like http://192.168.1.23:5000.
Open it on your phone and on the other device. Files uploaded on one appear on both.

## Notes
- Your computer's firewall must allow incoming connections on port 5000.
- Files are stored in the `shared/` folder. Delete them from the page or the folder.
- Anyone on your WiFi can open the page. Use it on networks you trust.
