"""WiFi Drop: send files between devices on the same network."""
import os
import socket
import uuid
from pathlib import Path

from flask import (Flask, abort, jsonify, render_template, request,
                   send_from_directory)
from werkzeug.security import safe_join
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", BASE_DIR / "shared"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

PORT = int(os.environ.get("PORT", 5000))

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 ** 3  # 2 GB per request


def lan_ip() -> str:
    """Best-effort local network address of this machine."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no packets are actually sent
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def unique_name(name: str) -> str:
    name = secure_filename(name) or f"file-{uuid.uuid4().hex[:6]}"
    path = UPLOAD_DIR / name
    stem, suffix = path.stem, path.suffix
    n = 1
    while path.exists():
        path = UPLOAD_DIR / f"{stem} ({n}){suffix}"
        n += 1
    return path.name


def list_files():
    items = []
    for p in UPLOAD_DIR.iterdir():
        if p.is_file():
            st = p.stat()
            items.append({"name": p.name, "size": st.st_size, "time": st.st_mtime})
    items.sort(key=lambda i: i["time"], reverse=True)
    return items


@app.get("/")
def index():
    return render_template("index.html", address=f"http://{lan_ip()}:{PORT}")


@app.get("/api/files")
def api_files():
    return jsonify(list_files())


@app.post("/api/upload")
def api_upload():
    files = request.files.getlist("files")
    if not files:
        return jsonify(error="No file received."), 400
    saved = []
    for f in files:
        if not f.filename:
            continue
        name = unique_name(f.filename)
        f.save(UPLOAD_DIR / name)
        saved.append(name)
    return jsonify(saved=saved)


@app.get("/download/<path:name>")
def download(name):
    return send_from_directory(UPLOAD_DIR, name, as_attachment=True)


@app.post("/api/delete/<path:name>")
def delete(name):
    path = safe_join(str(UPLOAD_DIR), name)
    if not path or not os.path.isfile(path):
        abort(404)
    os.remove(path)
    return jsonify(deleted=name)


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="File is larger than the 2 GB limit."), 413


if __name__ == "__main__":
    print(f"\n  WiFi Drop is running.\n  Open on any device on your WiFi: http://{lan_ip()}:{PORT}\n")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
