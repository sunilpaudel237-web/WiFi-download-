(() => {
  const drop = document.getElementById("drop");
  const picker = document.getElementById("picker");
  const uploadsEl = document.getElementById("uploads");
  const filesEl = document.getElementById("files");
  const emptyEl = document.getElementById("empty");
  let busy = 0;

  const fmtSize = (n) => {
    const u = ["B", "KB", "MB", "GB"];
    let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(n < 10 && i ? 1 : 0)} ${u[i]}`;
  };
  const fmtTime = (t) => new Date(t * 1000).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  async function refresh() {
    if (busy) return;
    try {
      const res = await fetch("/api/files", { cache: "no-store" });
      const files = await res.json();
      filesEl.replaceChildren(...files.map(renderFile));
      emptyEl.hidden = files.length > 0;
    } catch (_) { /* network blip: try again on next poll */ }
  }

  function renderFile(f) {
    const li = el("li");
    const info = el("div", "f-info");
    info.append(el("div", "f-name", f.name), el("div", "f-meta", `${fmtSize(f.size)} · ${fmtTime(f.time)}`));

    const dl = el("a", "btn", "Download");
    dl.href = "/download/" + encodeURIComponent(f.name);

    const del = el("button", "btn ghost", "Delete");
    del.type = "button";
    del.addEventListener("click", async () => {
      if (!confirm(`Delete ${f.name}?`)) return;
      await fetch("/api/delete/" + encodeURIComponent(f.name), { method: "POST" });
      refresh();
    });

    li.append(info, dl, del);
    return li;
  }

  function uploadOne(file) {
    const li = el("li");
    const row = el("div", "u-row");
    const state = el("span", "u-state", "0%");
    row.append(el("span", "u-name", file.name), state);
    const bar = el("div", "bar");
    const fill = el("i");
    bar.append(fill);
    li.append(row, bar);
    uploadsEl.prepend(li);

    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/upload");
      xhr.upload.onprogress = (e) => {
        if (!e.lengthComputable) return;
        const pct = Math.round((e.loaded / e.total) * 100);
        fill.style.width = pct + "%";
        state.textContent = pct + "%";
      };
      xhr.onload = () => {
        if (xhr.status === 200) {
          fill.style.width = "100%";
          state.textContent = "Sent";
          state.classList.add("done");
          setTimeout(() => li.remove(), 2500);
        } else {
          let msg = "Failed";
          try { msg = JSON.parse(xhr.responseText).error || msg; } catch (_) {}
          state.textContent = msg;
          state.classList.add("fail");
        }
        resolve();
      };
      xhr.onerror = () => {
        state.textContent = "Connection lost. Try again.";
        state.classList.add("fail");
        resolve();
      };
      const fd = new FormData();
      fd.append("files", file, file.name);
      xhr.send(fd);
    });
  }

  async function handle(fileList) {
    const files = [...fileList];
    if (!files.length) return;
    busy++;
    await Promise.all(files.map(uploadOne));
    busy--;
    refresh();
  }

  picker.addEventListener("change", () => { handle(picker.files); picker.value = ""; });
  drop.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); picker.click(); }
  });
  ["dragenter", "dragover"].forEach((t) =>
    drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach((t) =>
    drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", (e) => handle(e.dataTransfer.files));

  refresh();
  setInterval(refresh, 3000);
})();
